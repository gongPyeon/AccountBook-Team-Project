package AccountBook;

import java.util.ArrayList;

public abstract class TestMain {

	public static void main(String[] args) {
		AccountBookDao dao  = new AccountBookDao();
//		MainProgram main  = new MainProgram();
		ArrayList<AccountBookVO> a;
		
	}

}
