package AccountBook;

public class Process1 {
	AccountBookDao dao = new AccountBookDao();
	
	public Process1() {
		//dao.delete_schedule(1);    // 이런 식으로 데이터베이스에서 사용합니다.
	}
}
